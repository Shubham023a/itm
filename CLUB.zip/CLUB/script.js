// Mobile Menu Toggle with Animation
const hamburger = document.querySelector('.hamburger');
const navLinks = document.querySelector('.nav-links');

hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    navLinks.classList.toggle('active');
});

// Close mobile menu when clicking outside
document.addEventListener('click', (e) => {
    if (!hamburger.contains(e.target) && !navLinks.contains(e.target)) {
        hamburger.classList.remove('active');
        navLinks.classList.remove('active');
    }
});

// Smooth Scrolling for Navigation Links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        const headerOffset = 70;
        const elementPosition = target.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

        window.scrollTo({
            top: offsetPosition,
            behavior: 'smooth'
        });

        // Close mobile menu after clicking a link
        hamburger.classList.remove('active');
        navLinks.classList.remove('active');
    });
});

// Google Form URLs for different clubs
const formUrls = {
    coding: 'https://docs.google.com/forms/d/e/YOUR_FORM_ID_1/viewform?embedded=true',
    robotics: 'https://docs.google.com/forms/d/e/YOUR_FORM_ID_2/viewform?embedded=true',
    photography: 'https://docs.google.com/forms/d/e/YOUR_FORM_ID_3/viewform?embedded=true',
    cultural: 'https://docs.google.com/forms/d/e/YOUR_FORM_ID_4/viewform?embedded=true',
    sports: 'https://docs.google.com/forms/d/e/YOUR_FORM_ID_5/viewform?embedded=true',
    literary: 'https://docs.google.com/forms/d/e/YOUR_FORM_ID_6/viewform?embedded=true'
};

// Create Modal Element
const modal = document.createElement('div');
modal.className = 'modal';
modal.innerHTML = `
    <div class="modal-content">
        <span class="close-modal">&times;</span>
        <iframe src="" frameborder="0" marginheight="0" marginwidth="0">Loading…</iframe>
    </div>
`;
document.body.appendChild(modal);

// Open Form Modal with Animation
function openForm(clubType) {
    const iframe = modal.querySelector('iframe');
    iframe.src = formUrls[clubType];
    modal.style.display = 'flex';
    // Trigger reflow
    modal.offsetHeight;
    modal.classList.add('active');
}

// Close Modal with Animation
const closeModal = document.querySelector('.close-modal');
closeModal.addEventListener('click', () => {
    modal.classList.remove('active');
    setTimeout(() => {
        modal.style.display = 'none';
        modal.querySelector('iframe').src = '';
    }, 300);
});

// Close Modal when clicking outside
modal.addEventListener('click', (e) => {
    if (e.target === modal) {
        modal.classList.remove('active');
        setTimeout(() => {
            modal.style.display = 'none';
            modal.querySelector('iframe').src = '';
        }, 300);
    }
});

// Enhanced Scroll Animation
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate');
            // Unobserve after animation
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Observe all sections and cards
document.querySelectorAll('section, .club-card').forEach(element => {
    observer.observe(element);
});

// Navbar Scroll Effect with Enhanced Animation
let lastScroll = 0;
const navbar = document.querySelector('.navbar');

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll <= 0) {
        navbar.style.transform = 'translateY(0)';
        navbar.style.background = 'rgba(255, 255, 255, 0.95)';
        navbar.style.boxShadow = 'none';
        return;
    }
    
    if (currentScroll > lastScroll && currentScroll > 70) {
        // Scrolling down
        navbar.style.transform = 'translateY(-100%)';
    } else {
        // Scrolling up
        navbar.style.transform = 'translateY(0)';
        navbar.style.background = 'rgba(255, 255, 255, 0.95)';
        navbar.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
    }
    
    lastScroll = currentScroll;
});

// Add hover effect to club cards
document.querySelectorAll('.club-card').forEach(card => {
    card.addEventListener('mouseenter', () => {
        card.style.transform = 'translateY(-10px) scale(1.02)';
    });
    
    card.addEventListener('mouseleave', () => {
        card.style.transform = 'translateY(0) scale(1)';
    });
});

// 3D Card Effect
document.querySelectorAll('.club-card').forEach(card => {
    card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        
        const rotateX = (y - centerY) / 10;
        const rotateY = (centerX - x) / 10;
        
        card.style.transform = `
            perspective(1000px)
            rotateX(${rotateX}deg)
            rotateY(${rotateY}deg)
            translateZ(10px)
        `;
    });
    
    card.addEventListener('mouseleave', () => {
        card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) translateZ(0)';
    });
    
    // Add click event for card flip
    card.addEventListener('click', () => {
        card.classList.toggle('flipped');
    });
});

// Enhanced Card Hover Effects
document.querySelectorAll('.club-card').forEach(card => {
    const icon = card.querySelector('.club-icon');
    const title = card.querySelector('h3');
    const description = card.querySelector('p');
    const button = card.querySelector('.join-btn');
    
    card.addEventListener('mouseenter', () => {
        // Add floating animation to icon
        icon.style.animation = 'float 3s ease-in-out infinite';
        
        // Add glow effect
        card.style.boxShadow = '0 15px 35px rgba(52, 152, 219, 0.2)';
        
        // Add subtle scale to elements
        title.style.transform = 'translateZ(20px)';
        description.style.transform = 'translateZ(10px)';
        button.style.transform = 'translateZ(30px) scale(1.05)';
    });
    
    card.addEventListener('mouseleave', () => {
        // Reset animations and transforms
        icon.style.animation = '';
        card.style.boxShadow = '';
        title.style.transform = '';
        description.style.transform = '';
        button.style.transform = '';
    });
});

// Add parallax effect to cards
document.addEventListener('mousemove', (e) => {
    const cards = document.querySelectorAll('.club-card');
    const mouseX = e.clientX / window.innerWidth;
    const mouseY = e.clientY / window.innerHeight;
    
    cards.forEach((card, index) => {
        const offsetX = (mouseX - 0.5) * (index + 1) * 10;
        const offsetY = (mouseY - 0.5) * (index + 1) * 10;
        
        card.style.transform = `
            translateX(${offsetX}px)
            translateY(${offsetY}px)
            rotateX(${offsetY * 0.5}deg)
            rotateY(${offsetX * 0.5}deg)
        `;
    });
});

// Reset card positions when mouse leaves window
document.addEventListener('mouseleave', () => {
    const cards = document.querySelectorAll('.club-card');
    cards.forEach(card => {
        card.style.transform = '';
    });
});

// Create particles for hero section
function createParticles() {
    const particlesContainer = document.querySelector('.particles');
    const particleCount = 50;

    for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        
        // Random position
        particle.style.left = Math.random() * 100 + '%';
        particle.style.top = Math.random() * 100 + '%';
        
        // Random size
        const size = Math.random() * 3 + 1;
        particle.style.width = size + 'px';
        particle.style.height = size + 'px';
        
        // Random animation duration
        particle.style.animationDuration = Math.random() * 10 + 5 + 's';
        
        // Random delay
        particle.style.animationDelay = Math.random() * 5 + 's';
        
        particlesContainer.appendChild(particle);
    }
}

// Call the function when the page loads
document.addEventListener('DOMContentLoaded', createParticles); 